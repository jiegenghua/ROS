#include <math.h>
#include "TaskWaitForFace.h"
#include "floor_nav/TaskWaitForFaceConfig.h"
using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;


TaskIndicator TaskWaitForFace::iterate()
{
	printf("STARTED WAIT FOR FACE");
    const sensor_msgs::RegionOfInterest & tface= env->getFace();
     cfg.face_x=tface.x_offset;
     cfg.face_y=tface.y_offset;
      ROS_INFO("Got data from face!!");
      ROS_INFO("%.2f %.2f",cfg.face_x,cfg.face_y);
    if (cfg.face_x != 0 && cfg.face_y != 0) {
        cfg.face_x = 0;
        cfg.face_y = 0;
        ROS_INFO("Detected Face at %.2f %.2f",cfg.face_x,cfg.face_y);
		return TaskStatus::TASK_COMPLETED;
    }
	return TaskStatus::TASK_RUNNING;
}

DYNAMIC_TASK(TaskFactoryWaitForFace);

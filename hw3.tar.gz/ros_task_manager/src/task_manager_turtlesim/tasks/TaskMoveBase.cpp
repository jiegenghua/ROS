
#include "TaskMoveBase.h"
using namespace task_manager_turtlesim;

DYNAMIC_TASK(TaskFactoryMoveBase);

#!/usr/bin/env python
import roslib; roslib.load_manifest('rover_driver_base')
import rospy
from geometry_msgs.msg import Twist
import numpy, math
from numpy.linalg import pinv
from math import atan2, hypot, pi, cos, sin, fmod
import tf

prefix=["FL","FR","CL","CR","RL","RR"]

class RoverMotors:
    def __init__(self):
        self.steering={}
        self.drive={}
        for k in prefix:
            self.steering[k]=0.0
            self.drive[k]=0.0
    def copy(self,value):
        for k in prefix:
            self.steering[k]=value.steering[k]
            self.drive[k]=value.drive[k]

class DriveConfiguration:
    def __init__(self,radius,x,y,z):
        self.x = x
        self.y = y
        self.z = z
        self.radius = radius


class RoverKinematics:
    def __init__(self):
        self.X = numpy.asmatrix(numpy.zeros((3,1)))
        self.motor_state = RoverMotors()
        self.first_run = True
        self.listener=tf.TransformListener()

    def twist_to_motors(self, twist, drive_cfg, skidsteer=False):
        motors = RoverMotors()
        count = 0
        cont_loop = True
        if skidsteer:
            for k in prefix:
                # Insert here the steering and velocity of 
                # each wheel in skid-steer mode
                vx = twist.linear.x
                vy = twist.linear.y
                omega = twist.angular.z
                Wx = drive_cfg[k].x
                Wy = drive_cfg[k].y
                vw_x = vx - omega*Wy
                vw_y = vy + omega*Wx
                beta = atan2(vw_y, vw_x) #beta is the steering angle
                phiw = hypot(vw_y, vw_x)
                self.vwx=vw_x
                self.vwy=vw_y
                motors.steering[k] = beta
                motors.drive[k] = 10*phiw
                
        else:
            for k in prefix:
                # Insert here the steering and velocity of 
                # each wheel in rolling-without-slipping mode
                #print(k)
                #print(prefix)
                vx = twist.linear.x
                vy = twist.linear.y
                omega = twist.angular.z
                Wx = drive_cfg[k].x
                Wy = drive_cfg[k].y
                vw_x = vx - omega*Wy
                vw_y = vy + omega*Wx
                beta = atan2(vw_y, vw_x) #beta is the steering angle
                phiw = hypot(vw_y, vw_x) #divide by radius here?
                self.vwx=vw_x
                self.vwy=vw_y
                motors.steering[k]=0
                motors.drive[k] = 10*phiw
                #if count == 6:
				#	cont_loop = False
                if beta <= pi/2 or beta >= -pi/2:
					motors.steering[k] = beta
					motors.drive[k] = 10*phiw
                elif pi/2 < beta <= pi:
					#motors.steering[k] = pi/2 - beta
					motors.steering[k] = beta + pi
					motors.drive[k] = -10*phiw
                else: # beta is less than -pi/2
					#motors.steering[k] = -1*beta - pi/2
					motors.steering[k] = beta - pi
					motors.drive[k] = -10*phiw
                count = count + 1
        return motors

    def integrate_odometry(self, motor_state, drive_cfg):
        # The first time, we need to initialise the state
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            return self.X
        # Insert here your odometry code
        A = []
        B = []
        total_X = []
        for k in drive_cfg.keys():
			s = 0
			beta = 0

			beta = motor_state.drive[k] - self.motor_state.drive[k]
			beta = numpy.mod(beta + math.pi, 2*math.pi) - math.pi

			s = beta*drive_cfg[k].radius
			row1 = [1, 0, -1*drive_cfg[k].y]
			row2 = [0, 1, drive_cfg[k].x]
			A.append(row1)
			A.append(row2)
			brow1 = s*cos(motor_state.steering[k])
			brow2 = s*sin(motor_state.steering[k])
			B.append(brow1)
			B.append(brow2)
        test = beta*drive_cfg['FL'].radius
        A = numpy.array(A)
        B = numpy.array(B)
        added = numpy.dot(pinv(A),B)
        added=added.T
        added2 = numpy.empty([3,1])
        count = 0
        for element in added:
			added2[count,0] = element
			count += 1
        added2[0,0]=added2[0,0]*cos(self.X[2,0])-added2[1,0]*sin(self.X[2,0])
        added2[1,0]=added2[0,0]*sin(self.X[2,0])+added2[1,0]*cos(self.X[2,0])
        added2[2,0]=added2[2,0]
        #print(self.X)
        self.X[2,0] = added2[2,0] + self.X[2,0]
        self.X[1,0] = added2[1,0] + self.X[1,0]
        self.X[0,0] = added2[0,0] + self.X[0,0]
        #print(self.X)
        self.motor_state.copy(motor_state)
        return self.X

